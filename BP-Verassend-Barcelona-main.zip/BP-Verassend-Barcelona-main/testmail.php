<?php
  
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
  
require 'vendor/autoload.php';

include 'reservatie.php';

if(isset($_POST['submit'])){
    // Get the submitted form data
    $postData = $_POST;
    $email = $_POST['email'];
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
}
    
$mail = new PHPMailer(true);
  
try {
    $mail->SMTPDebug = 2;                                       
    $mail->isSMTP();                                            
    $mail->Host       = 'smtp.gmail.com;';                    
    $mail->SMTPAuth   = true;                             
    $mail->Username   = 'bobdebouwer19482@gmail.com';                 
    $mail->Password   = 'fazxbjgzzeyfmcza';                        
    $mail->SMTPSecure = 'starttls';                              
    $mail->Port       = 587;  
  
    $mail->setFrom('bobdebouwer19482@gmail.com', 'Uw reservering');           
    $mail->addAddress('bobdebouwer19482@gmail.com');
    $mail->addAddress('bobdebouwer19482@gmail.com', 'Uriech');
       
    $mail->isHTML(true);                                  
    $mail->Subject = 'Reservatie';

    
    $mail->Body    = 'Bedankt voor uw reservatie ' . $name;
    
    $mail->AltBody = 'Body in plain text for non-HTML mail clients';
    $mail->send();
    echo "Mail has been sent successfully!";
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?>